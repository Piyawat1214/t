// generate-hwid.js
const { execSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');

function sha256Hex(input) {
  return crypto.createHash('sha256').update(input, 'utf8').digest('hex');
}

function readFileIfExists(p) {
  try { return fs.readFileSync(p, 'utf8').trim(); } catch(e){ return null; }
}

function writeFileSafe(p, v) {
  try {
    fs.writeFileSync(p, v, { mode: 0o600 });
    return true;
  } catch(e){ return false; }
}

function tryCmd(cmd) {
  try {
    const out = execSync(cmd, { timeout: 2000 }).toString().trim();
    if (out) return out.replace(/\r/g,'').trim();
  } catch(e) {}
  return null;
}

function getMachineIdLinux() {
  const candidates = ['/etc/machine-id', '/var/lib/dbus/machine-id'];
  for (const c of candidates) {
    const v = readFileIfExists(c);
    if (v) return v;
  }
  const uuid = readFileIfExists('/sys/class/dmi/id/product_uuid');
  if (uuid) return uuid;
  return null;
}

function getMachineIdMac() {
  let out = tryCmd("ioreg -rd1 -c IOPlatformExpertDevice | awk '/IOPlatformUUID/ { print $3; }'");
  if (out) return out.replace(/"/g,'').trim();
  out = tryCmd("system_profiler SPHardwareDataType | awk '/Hardware UUID/ { print $3; }'");
  if (out) return out.trim();
  return null;
}

function getMachineIdWindows() {
  let out = tryCmd('wmic csproduct get uuid 2>nul | findstr /r /v "^$"');
  if (out) {
    const lines = out.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
    for (const l of lines) {
      if (!/uuid/i.test(l)) return l;
    }
    if (lines.length >= 2) return lines[1];
  }
  out = tryCmd('reg query HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Cryptography /v MachineGuid 2>nul');
  if (out) {
    const m = out.match(/MachineGuid\s+REG_SZ\s+([^\r\n]+)/i);
    if (m) return m[1].trim();
  }
  return null;
}

function getMacAddresses() {
  try {
    const ifaces = os.networkInterfaces();
    const macs = [];
    for (const k of Object.keys(ifaces)) {
      for (const a of ifaces[k]) {
        if (a && a.mac && a.mac !== '00:00:00:00:00:00') macs.push(a.mac);
      }
    }
    return Array.from(new Set(macs)).join(',');
  } catch(e) { return null; }
}

function generatePersistentFallback() {
  const file = path.join(os.homedir(), '.local-hwid');
  const existing = readFileIfExists(file);
  if (existing) return existing.trim();
  const val = 'hwid-fallback-' + crypto.randomBytes(16).toString('hex');
  writeFileSafe(file, val);
  return val;
}

function buildHwid() {
  const platform = process.platform;
  let base = null;

  if (platform === 'linux') {
    base = getMachineIdLinux();
  } else if (platform === 'darwin') {
    base = getMachineIdMac();
  } else if (platform === 'win32') {
    base = getMachineIdWindows();
  }

  const macs = getMacAddresses();
  const hostname = os.hostname();
  const osinfo = `${os.type()}:${os.release()}:${os.arch()}`;

  if (!base) base = generatePersistentFallback();

  const combined = `BASE:${base}||MACS:${macs || 'nomac'}||HOST:${hostname}||OS:${osinfo}`;
  return sha256Hex(combined);
}

if (require.main === module) {
  const hwid = buildHwid();
  console.log(hwid);
  process.exit(0);
} else {
  module.exports = buildHwid;
}
