require('dotenv').config();
console.log('Loaded ADMIN_HWID:', process.env.ADMIN_HWID);

const express = require('express');
const fs = require('fs-extra');
const path = require('path');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');

let twvoucher;
try {
  twvoucher = require('./tw-voucher');
  if (twvoucher.default) twvoucher = twvoucher.default; // ✅ เพิ่มบรรทัดนี้
} catch (e) {
  console.warn('Warning: tw-voucher not found.');
  twvoucher = null;
}

const app = express();
app.use(express.json());

// ---------------- CONFIG ----------------
const DATA_DIR = path.join(__dirname);
const TOKEN_FILE = path.join(DATA_DIR, 'token.json');
const USAGE_LOG = path.join(DATA_DIR, 'usage.log');

fs.ensureFileSync(TOKEN_FILE);
if (!fs.readJsonSync(TOKEN_FILE, { throws: false })) {
  fs.writeJsonSync(TOKEN_FILE, { tokens: [] }, { spaces: 2 });
}
fs.ensureFileSync(USAGE_LOG);

const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || 'admin_test_key';
const ADMIN_HWID = process.env.ADMIN_HWID || '';
const RATE_LIMIT_WINDOW_MINUTES = Number(process.env.RATE_MINUTES) || 1;
const RATE_LIMIT_MAX = Number(process.env.RATE_MAX) || 10;

// ---------------- HELPERS ----------------
function readTokens() { return fs.readJsonSync(TOKEN_FILE, { throws: false }) || { tokens: [] }; }
function writeTokens(obj) { fs.writeJsonSync(TOKEN_FILE, obj, { spaces: 2 }); }
function maskPhone(phone) { if (!phone) return ''; return phone.replace(/\d(?=\d{3})/g, '*'); }
function shortToken(tok) { return tok.slice(0,6) + '...' + tok.slice(-4); }
function logUsage(entry) { fs.appendFileSync(USAGE_LOG, JSON.stringify(entry) + '\n'); }

// Rate limit
const redeemLimiter = rateLimit({
  windowMs: RATE_LIMIT_WINDOW_MINUTES * 60 * 1000,
  max: RATE_LIMIT_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => res.status(429).json({ error: 'Too many requests' })
});

// ---------------- ADMIN AUTH ----------------
function adminAuth(req, res, next) {
  const key = req.header('x-admin-key');
  const hwid = req.header('x-hwid');
  if (!key || key !== ADMIN_KEY) return res.status(401).json({ error: 'Invalid admin key' });
  if (!ADMIN_HWID) return res.status(500).json({ error: 'Server missing ADMIN_HWID' });
  if (!hwid || hwid !== ADMIN_HWID) return res.status(403).json({ error: 'HWID mismatch' });
  next();
}

// ---------------- TOKEN AUTH (no hwid) ----------------
function tokenAuth(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing Authorization header' });
  }
  const token = auth.split(' ')[1];
  const store = readTokens();
  const rec = store.tokens.find(t => t.token === token && !t.revoked);
  if (!rec) return res.status(403).json({ error: 'Invalid or revoked token' });
  req.tokenRecord = rec;
  next();
}

// ---------------- ADMIN ROUTES ----------------
app.post('/admin/create-token', adminAuth, (req, res) => {
  const { label } = req.body || {};
  const token = crypto.randomBytes(24).toString('hex');
  const store = readTokens();
  store.tokens.push({
    token,
    label: label || null,
    created_at: new Date().toISOString(),
    revoked: false
  });
  writeTokens(store);
  res.json({ token });
});

app.get('/admin/list-tokens', adminAuth, (req, res) => {
  const store = readTokens();
  const out = store.tokens.map(t => ({
    token_preview: shortToken(t.token),
    label: t.label,
    created_at: t.created_at,
    revoked: t.revoked
  }));
  res.json(out);
});

app.post('/admin/revoke-token', adminAuth, (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ error: 'token required' });
  const store = readTokens();
  const rec = store.tokens.find(t => t.token === token || t.token.startsWith(token));
  if (!rec) return res.status(404).json({ error: 'token not found' });
  rec.revoked = true;
  writeTokens(store);
  res.json({ ok: true, token_preview: shortToken(rec.token) });
});

// ---------------- USER ROUTE ----------------
app.post('/api/redeem', redeemLimiter, tokenAuth, async (req, res) => {
  const { phone, codeOrUrl } = req.body;
  const tokenRec = req.tokenRecord;

  if (!phone || !codeOrUrl) {
    logUsage({ time: new Date().toISOString(), status: 'bad_request', phone, token: shortToken(tokenRec.token) });
    return res.status(400).json({ error: 'phone and codeOrUrl required' });
  }

  if (!twvoucher) {
    const msg = 'tw-voucher module not installed';
    logUsage({ time: new Date().toISOString(), status: 'fail', msg });
    return res.status(500).json({ error: msg });
  }

  try {
    const result = await twvoucher(phone, codeOrUrl);
    logUsage({ time: new Date().toISOString(), status: 'success', token: shortToken(tokenRec.token), phone: maskPhone(phone) });
    return res.json({ success: true, result });
  } catch (err) {
    logUsage({ time: new Date().toISOString(), status: 'error', msg: err.message });
    return res.status(400).json({ success: false, message: err.message });
  }
});

app.get('/', (req, res) => res.send('tw-voucher API (admin locked, user token only) running'));

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
